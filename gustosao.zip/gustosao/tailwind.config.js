/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      colors:{
        Laranja:'#E8590C',
      },  
    },
  },
  plugins: [],
}

